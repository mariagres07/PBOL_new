package org.example.restapidemoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiDemooApplicationTests {

    @Test
    void contextLoads() {
    }

}
