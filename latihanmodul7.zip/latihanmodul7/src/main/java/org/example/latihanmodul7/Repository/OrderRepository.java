package org.example.latihanmodul7.Repository;

import org.example.latihanmodul7.Model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {

}
