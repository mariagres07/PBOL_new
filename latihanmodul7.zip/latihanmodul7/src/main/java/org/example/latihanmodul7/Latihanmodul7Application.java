package org.example.latihanmodul7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Latihanmodul7Application {

    public static void main(String[] args) {
        SpringApplication.run(Latihanmodul7Application.class, args);
    }

}



