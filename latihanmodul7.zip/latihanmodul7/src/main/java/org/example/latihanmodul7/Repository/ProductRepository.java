package org.example.latihanmodul7.Repository;

import org.example.latihanmodul7.Model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {

}


