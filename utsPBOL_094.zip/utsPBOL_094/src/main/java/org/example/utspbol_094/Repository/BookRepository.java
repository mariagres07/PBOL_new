package org.example.utspbol_094.Repository;

import org.example.utspbol_094.Model.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> {
}
