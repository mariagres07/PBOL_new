package org.example.utspbol_094.Repository;

import org.example.utspbol_094.Model.Member;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MemberRepository extends JpaRepository<Member, Long> {
}
