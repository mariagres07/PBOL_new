package org.example.utspbol_094;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtsPbol094ApplicationTests {

    @Test
    void contextLoads() {
    }

}
