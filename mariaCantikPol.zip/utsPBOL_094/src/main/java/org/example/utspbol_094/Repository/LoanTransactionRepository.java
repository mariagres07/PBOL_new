package org.example.utspbol_094.Repository;

import org.example.utspbol_094.Model.LoanTransaction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanTransactionRepository extends JpaRepository<LoanTransaction, Long> {
}
