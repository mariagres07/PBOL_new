package org.example.utspbol_094.Service;

import org.example.utspbol_094.Model.LoanTransaction;
import org.example.utspbol_094.Model.LoanTransaction;
import org.example.utspbol_094.Repository.LoanTransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoanTransactionService {
    @Autowired
    private LoanTransactionRepository loanTransactionRepository;

    //menampilkan daftar semua transaksi peminjaman
    public List<LoanTransaction> getAllLoanTransaction(){ return loanTransactionRepository.findAll();}

    //Mendapatkan transaksi peminjaman berdasarkan ID
//    public Optional<LoanTransaction> getLoanTransactionById(Long Id){ return loanTransactionRepository.findById(Id);}

    // Menyimpan transaksi peminjaman baru
    public LoanTransaction saveLoanTransaction(LoanTransaction loanTransaction){
        return loanTransactionRepository.save(loanTransaction);
    }

    //Memperbarui informasi buku berdasarkan ID.
    public LoanTransaction updateLoanTransaction(Long id, LoanTransaction updatedLoanTransaction){
        Optional<LoanTransaction> bookOptional = loanTransactionRepository.findById(id);
        if (bookOptional.isPresent()) {
            LoanTransaction existingLoanTransaction = bookOptional.get();
            existingLoanTransaction.setBook(updatedLoanTransaction.getBook());
            existingLoanTransaction.setMember(updatedLoanTransaction.getMember());
            existingLoanTransaction.setBorrowDate(updatedLoanTransaction.getBorrowDate());
            existingLoanTransaction.setReturnDate(updatedLoanTransaction.getReturnDate());
            return loanTransactionRepository.save(existingLoanTransaction); // Simpan perubahan
        }
        return null;
    }

    //Menghapus transaksi peminjaman berdasarkan ID
    public void deleteLoanTransaction(Long id){
        loanTransactionRepository.deleteById(id);
    }
}
